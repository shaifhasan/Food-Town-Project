<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="{{route('create')}}">Create</a>
	<br/>
	<br/>
	<p>Your name is {{$name}}</p>
	<p>Your email is {{$email}}</p>
	<p>Your email is {{$age}}</p>
</body>
</html>