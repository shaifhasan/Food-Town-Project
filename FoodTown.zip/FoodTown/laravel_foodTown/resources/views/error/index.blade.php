<!DOCTYPE html>
<html>
<head>
	<title>Error</title>
</head>
<body>
<h1>Unauthorised Access!! Something Went Wrong! Please <a href="{{route('logout')}}">Try Login Again!</a>. </h1>
</body>
</html>