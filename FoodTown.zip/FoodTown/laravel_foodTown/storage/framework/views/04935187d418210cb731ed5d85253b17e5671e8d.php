<?php $__env->startSection('pagetitle'); ?> Home | Customer <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('customerProfile')); ?>">Profile</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('customerItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('order'); ?> <a href="<?php echo e(route('customerCart&Order')); ?>">Cart & Order</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('customerChangePass.edit', ['id' => $customerDetails->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style type="text/css">
table, tr, td, a{
color: black;
    padding-top: 10px;
    font-size: 16px;
     border-collapse: collapse;
}
#tabletop
{
   margin-top: 30px;
}
#td
{
	margin-right:10px;
}
#divbox
{
	background-color: #e8e4e2;
	height: 300px;
	position: static;
	width: 1450px;
	overflow-y: scroll;
	margin-left: -530px;
	box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
}
	
	
}
#float1{
	background-color: #f7f5ec;
    box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
    width: 1450px;
}

input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    background-color : #d1d1d1; 
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #d1d1d1;
    color: black;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color:#f7f5ec;
}

	
</style>
<form method="post">
		<?php echo e(csrf_field()); ?>

	<h2>Welcome Customer, <?php echo e($customerDetails->name); ?></h2>
	<table id="tabletop">
		<tr>
				<td colspan="3"><h3>Search for Items and Resturent</h3></td>
				
			</tr>
			<tr>
				<td></td>
				<td id="td"><input type="text"  placeholder="Search.." value="<?php echo e(old('oldsearch')); ?>" name="oldsearch"/></td>
				<td id="td"><select name="type">
						  <option value="items" >Items</option>
						  <option value="restaurants" >Restaurants</option>
				     </select>
				</td>
				<td id="td"><input type="submit" value="Search"  /></td>
			</tr>
		</table>
		<?php if(!empty($itemDetails)): ?>
	<div id="divbox" style="float: left;">
	<?php $__currentLoopData = $itemDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div id="float1" style="height: 110px">
		<table style="margin-left: 30px">
		
		<tr >
			<td>
				<img style="border: 1px solid black;width: 100px;height: 90px;border-radius: 15%;" src="../../../uploads/itemPhotos/<?php echo e($item->photo); ?>">
			</td> 
			<td colspan="3" style="width: 1000px">
				<div style="float:left;margin-left: 10px">Name:<?php echo e($item->name); ?> </div><div style="float:right">Restaurant:<?php echo e($item->restaurantName); ?> </div><br><br>
				<div style="float:left;margin-left: 10px">Description:<?php echo e($item->description); ?></div><br><br>
				<div style="float:left;margin-left: 10px">Price:<?php echo e($item->regPrice); ?></div>
				<div style="float:right;margin-left: 10px"> <?php if($item->availability=="Yes"): ?> <a href="<?php echo e(route('customerItem.addToCart', ['itemID' => $item->itemID])); ?>">Add to cart</a>  <?php endif; ?></div>


			</td>
			</tr>
			</div>
		</table>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if(!empty($restaurantDetails)): ?>
	<div id="divbox" style="float: left;">
	<?php $__currentLoopData = $restaurantDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div id="float1" style="height: 110px">
		<table style="margin-left: 30px">
		
		<tr >
			<td>
				<img style="border: 1px solid black;width: 100px;height: 90px;border-radius: 15%;" src="../../../uploads/profilePhotos/<?php echo e($item->logo); ?>">
			</td> 
			<td colspan="3" style="width: 1000px">
				<div style="float:left;margin-left: 10px">Name:<?php echo e($item->restaurantName); ?> </div><br><br>
				<div style="float:left;margin-left: 10px">Address:<?php echo e($item->branch); ?>,<?php echo e($item->address); ?></div><br><br>
				<div style="float:left;margin-left: 10px">Owner:<?php echo e($item->ownerName); ?></div>
			   <div style="float:right;margin-left: 10px"> <a href="<?php echo e(route('customerView.restaurantDetails', ['userID' => $item->userID])); ?>">View Restaurant Details</a></div>


			</td>
			</tr>
			</div>
		</table>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
			

	</div>
	</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>