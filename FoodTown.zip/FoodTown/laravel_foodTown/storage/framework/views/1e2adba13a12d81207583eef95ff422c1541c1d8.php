<!DOCTYPE html>
<html>
<head>
	<title> <?php echo $__env->yieldContent('pagetitle'); ?> </title>
	<link rel="stylesheet" type="text/css" href="/css/global.css">

<div class="loginHeader"> 

	<span>Food Town</span>
		<nav>
			<ul>
				<li>
					<?php echo $__env->yieldContent('profile'); ?>
				</li>
				<li>
					<?php echo $__env->yieldContent('item'); ?>
				</li>
				<li>
					 <?php echo $__env->yieldContent('order'); ?>
				</li>
				<li>
					<?php echo $__env->yieldContent('changePass'); ?>
				</li>
				<li>
					<?php echo $__env->yieldContent('logout'); ?>
				</li>
			</ul>
		</nav>
	</div>

</head>
<body>

	<div id="Container" style="background: none; background-color: #ddd6af3d;">

		<div id="welcomebox">
			<?php echo $__env->yieldContent('content'); ?>  
		</div>

		<div id="validation">
			<?php echo $__env->yieldContent('validation'); ?>  
		</div>

		<?php echo $__env->yieldContent('fixedBottomLabel'); ?>

	</div>

</body>
</html>