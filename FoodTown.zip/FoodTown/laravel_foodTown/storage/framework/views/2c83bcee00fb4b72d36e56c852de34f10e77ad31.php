<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Delete Department</h2>
	<a href="<?php echo e(route('department.list')); ?>">Back to List</a>
	<br/><br/>
	<table>
		<tr>
			<td>ID</td>
			<td><?php echo e($department->department_id); ?></td>
		</tr>
		<tr>
			<td>NAME</td>
			<td><?php echo e($department->department_name); ?></td>
		</tr>
		<tr>
			<td>LOCATION</td>
			<td><?php echo e($department->location); ?></td>
		</tr>
	</table>
	<h4>This cannot be undone. Are you sure?</h4>
	<form method="post">
		<input type="hidden" name="did" value="<?php echo e($department->department_id); ?>">
		<input type="submit" value="Confirm"></td>
	</form>
</body>
</html>