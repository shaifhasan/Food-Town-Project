<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('pagetitle'); ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/bootstrap/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/bootstrap/bootstrap.theme.min.css')); ?>">
	<style type="text/css">
	.active{
		border: 1px solid;
		border-color: #337ab7;
	}
	</style>
	
	<?php echo $__env->yieldContent('styles'); ?>

	
	<script type="text/javascript" src="<?php echo e(asset('assets/jquery/jquery-3.3.1.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('assets/bootstrap/bootstrap.min.js')); ?>"></script>
	<?php echo $__env->yieldContent('scripts'); ?>
</head>
<body>
	
	<nav class="navbar">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="#">Employee Manager</a>
			</div>
			<ul class="nav navbar-nav">
				<li class="<?php echo e(Route::is('home') ? 'active' : ''); ?>"><a href="<?php echo e(route('home')); ?>">Home</a></li>
				<li class="<?php echo e(Route::is('department*') ? 'active' : ''); ?>"><a href="<?php echo e(route('department.list')); ?>">Departments</a></li>
				<li class="<?php echo e(Route::is('employee*') ? 'active' : ''); ?>"><a href="<?php echo e(route('employee.list')); ?>">Employees</a></li>
				<li class="<?php echo e(Route::is('file*') ? 'active' : ''); ?>"><a href="<?php echo e(route('file.index')); ?>">Files</a></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
			</ul>
		</div>
	</nav>

	<?php echo $__env->yieldContent('content'); ?>
						
</body>
</html>