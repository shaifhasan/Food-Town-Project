<?php $__env->startSection('pagetitle'); ?> Edit Profile | Restaurant <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('restaurantProfile')); ?>">Profile</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('restaurantItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('restaurantChangePass.edit', ['id' => $restaurantDetails->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<style type="text/css">

	table, tr, td, a{
color: black;
    padding-top: 10px;
    font-size: 16px;
     border-collapse: collapse;
}

#welcomebox {
    width: 440px;
    height: 520px;
    background: #58584a75;
    position: absolute;
    color: #000;
    padding-left: 3.5%;
    margin-top: 2%;
    margin-left: 35%;
}

#validation {
	width: 320px;
    height: 78px;
    color: #e42828;
    padding-top: 3px;
    margin-top: 15%;
    left: 450px;
}

</style>

<h2 style="position: relative; left: -20px;">Edit Profile</h2>
	<form method="post" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="userID" value="<?php echo e($restaurantDetails->userID); ?>">  
		<input type="hidden" name="logo" value="<?php echo e($restaurantDetails->logo); ?>">  
		<table>
			<tr>
				<td>
					<?php if($restaurantDetails->logo=="none"): ?>
						<img style="border-radius: 50%; border: 1px solid black; width: 80px; height: 80px;" src="../../../uploads/profilePhotos/default.jpg">
					<?php else: ?>
						<img style="border-radius: 50%; border: 1px solid black; width: 80px; height: 80px;" src="../../../uploads/profilePhotos/<?php echo e($restaurantDetails->logo); ?>">
					<?php endif; ?>
				</td>
				<td>
					<input type="file" name="file" accept="image/*">
				</td>
			</tr>
			<tr>
				<td>Name</td>
				<td><input type="text" name="restaurantName" value="<?php echo e($restaurantDetails->restaurantName); ?>"></td>
			</tr>
			<tr>
				<td>Branch</td>
				<td><input type="text" name="branch" value="<?php echo e($restaurantDetails->branch); ?>"></td>
			</tr>
			<tr>
				<td>Owner Name</td>
				<td><input type="text" name="owner" value="<?php echo e($restaurantDetails->ownerName); ?>"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="email" value="<?php echo e($restaurantDetails->email); ?>"></td>
			</tr>
			<tr>
				<td>Address</td>
				<td><input type="text" name="address" value="<?php echo e($restaurantDetails->address); ?>"></td>
			</tr>
			<tr>
				<td>Phone</td>
				<td><input type="text" name="phone" value="<?php echo e($restaurantDetails->phone); ?>"></td>
			</tr>
			<tr>
				<td>Opening Time</td>
				<td>
					<input type="number" name="openhh" min="1" max="12" placeholder="HH" 
					<?php if($restaurantDetails->openTime!="N/A"): ?> value="<?php echo e($openTime[0]); ?>" <?php endif; ?>> :
					<input type="number" name="openmm" min="0" max="12" placeholder="HH" 
					<?php if($restaurantDetails->openTime!="N/A"): ?> value="<?php echo e($openTime[1]); ?>" <?php endif; ?>> -
					<select name="openPeriod"> 
               	 	<option selected disabled>AM/PM</option>
                	<option <?php if($openTime[2]=="AM"): ?> selected <?php endif; ?> value="AM">AM </option>
                	<option <?php if($openTime[2]=="PM"): ?> selected <?php endif; ?> value="PM">PM</option>
                	</select>
				</td>
			</tr>
			<tr>
				<td>Closing Time</td>
				<td>
					<input type="number" name="closehh" min="1" max="12" placeholder="HH" 
					<?php if($restaurantDetails->closeTime!="N/A"): ?> value="<?php echo e($closeTime[0]); ?>" <?php endif; ?>> :
					<input type="number" name="closemm" min="0" max="12" placeholder="HH" 
					<?php if($restaurantDetails->closeTime!="N/A"): ?> value="<?php echo e($closeTime[1]); ?>" <?php endif; ?>> -
					<select name="closePeriod"> 
               	 	<option selected disabled>AM/PM</option>
                	<option <?php if($closeTime[2]=="AM"): ?> selected <?php endif; ?> value="AM">AM </option>
                	<option <?php if($closeTime[2]=="PM"): ?> selected <?php endif; ?> value="PM">PM</option>
                	</select>
				</td>
			</tr>
			<tr>
				<td>Service</td>
				<td>
					<select name="status"> 
               	 	<option selected disabled>open/close</option>
                	<option <?php if($restaurantDetails->status=="open"): ?> selected <?php endif; ?> value="open">Open </option>
                	<option <?php if($restaurantDetails->status=="close"): ?> selected <?php endif; ?> value="close">Close</option>
                	</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Update"></td>
			</tr>
		</table>
	</form>					
<?php $__env->stopSection(); ?>

<?php $__env->startSection('validation'); ?>
	<?php if($errors->any()): ?>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

 
 
<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>