<?php $__env->startSection('content'); ?>
	<h2>Employee List</h2>
	<a href="<?php echo e(route('home')); ?>">Back to Home</a> | 
	<a href="<?php echo e(route('employee.create')); ?>">Create New</a>
	<br/><br/>
	<div class="panel panel-info">
		<div class="panel-heading">List of Employee</div>
			<div class="panel-body">
	<table class="table table-striped">
		<tr>
			<th>ID</th>
			<th>NAME</th>
			<th>EMAIL</th>
			<th>SALARY</th>
			<th>DEPARTMENT</th>
			<th>OPTION</th>
		</tr>
		<?php $__currentLoopData = $emplist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($emp->employee_id); ?></td>
			<td><?php echo e($emp->employee_name); ?></td>
			<td><?php echo e($emp->email); ?></td>
			<td><?php echo e($emp->salary); ?></td>
			<td><?php echo e($emp->department->department_name); ?></td>
			<td><a href="#">Edit</a> | <a href="#">Delete</a></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</div>
</div>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('pagetitle'); ?>
		Employee List
	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>