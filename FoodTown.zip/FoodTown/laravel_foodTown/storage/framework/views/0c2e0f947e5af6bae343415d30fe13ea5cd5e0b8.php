<?php $__env->startSection('pagetitle'); ?> Profile | Restaurant <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('restaurantHome')); ?>">Home</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('restaurantItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('restaurantChangePass.edit', ['id' => $restaurantDetails->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
	table, tr, td, a{
color: black;
    padding-top: 10px;
    font-size: 16px;
     border-collapse: collapse;
}
#welcomebox {
    width: 420px;
    height: 485px;
    background: #58584a75;
    position: absolute;
    color: #000;
    padding-left: 5%;
    padding-top: 1.5%;
    margin-top: 3%;
    margin-left: 35%;
}

#validation {
    width: 0px;
    height: 0px;
}

</style>


	<table>
							
							<td colspan="2">
					<?php if($restaurantDetails->logo=="none"): ?>
						<img style="border-radius: 50%; border: 1px solid black; width: 80px; height: 80px;" src="../../../uploads/profilePhotos/default.jpg">
					<?php else: ?>
						<img style="border-radius: 50%; border: 1px solid black; width: 80px; height: 80px;" src="../../../uploads/profilePhotos/<?php echo e($restaurantDetails->logo); ?>">
					<?php endif; ?>
							</td>	

							<tr>
								<th>Restaurant Name : </th>
								<td><?php echo e($restaurantDetails->restaurantName); ?></td>
							</tr>

							<tr>
								<th>Branch : </th>
								<td><?php echo e($restaurantDetails->email); ?></td>
							</tr>

							<tr>
								<th>Owner Name : </th>
								<td><?php echo e($restaurantDetails->ownerName); ?></td>
							</tr>

							<tr>
								<th>Email : </th>
								<td><?php echo e($restaurantDetails->email); ?></td>
							</tr>

							<tr>
								<th>Address : </th>
								<td><?php echo e($restaurantDetails->address); ?></td>
							</tr>

							<tr>
								<th>Phone : </th>
								<td><?php echo e($restaurantDetails->phone); ?></td>
							</tr>

							<tr>
								<th>Opening Time : </th>
								<td><?php echo e($restaurantDetails->openTime); ?></td>
							</tr>

							<tr>
								<th>Closing Time : </th>
								<td><?php echo e($restaurantDetails->closeTime); ?></td>
							</tr>

							<tr>
								<th>Ratting : </th>
								<td><?php echo e($restaurantDetails->ratting); ?></td>
							</tr>

							<tr>
								<th>Join Date : </th>
								<td><?php echo e($restaurantDetails->createdAt); ?></td>
							</tr>

							<tr>
								<th>Service : </th>
								<td><?php echo e($restaurantDetails->status); ?></td>
							</tr>

							<tr>
								<th></th>
									<td>
										<a  href="<?php echo e(route('restaurantProfile.edit', ['id' => $restaurantDetails->userID])); ?>">Edit Profile</a>
									</td>
							</tr>
							
					</table>
					
					
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>