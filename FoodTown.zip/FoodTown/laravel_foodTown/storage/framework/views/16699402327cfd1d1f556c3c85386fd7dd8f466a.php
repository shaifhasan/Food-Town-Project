<?php $__env->startSection('pagetitle'); ?> Reset Password <?php $__env->stopSection(); ?>	

<?php $__env->startSection('legend'); ?>
<h2>Reset Password</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
	
	#loginbox {
    padding-left: 2%;
}

</style>

	<form method="post">
		<?php echo e(csrf_field()); ?>

		<table>
			<br>
			<br>
			<tr>
				<td>Enter Your Email</td>
				<td><input type="text" name="email"/></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Send Reset Link" /></td>
			</tr>
		</table>
	</form>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('validation'); ?>
		<?php if(session('message')): ?>
		<ul>
				<li><?php echo e(session('message')); ?></li>
		</ul>
	<?php endif; ?>

	<?php if($errors->any()): ?>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	<?php endif; ?>

	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>