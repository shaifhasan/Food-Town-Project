<?php $__env->startSection('pagetitle'); ?> Edit Profile | Restaurant <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('restaurantProfile')); ?>">Profile</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('restaurantItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('restaurantChangePass.edit', ['id' => $restaurantDetails->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<style type="text/css">
	
table, tr, td, a {
    color: #46433e;
    padding-left: 20px;
    text-align: center;
    margin: 0 auto;
    height: 38px;
}

#welcomebox {
    width: 490px;
    height: 530px;
    background: #58584a75;
    position: absolute;
    color: #000;
    padding-left: 0%;
    margin-top: 2%;
    margin-left: 8%;
}

#validation {
	width: 650px;
    height: 490px;
    color: #e42828;
    padding-top: 3px;
    margin-top: 3%;
    left: 110px;
}


</style>

<h2>Restaurent Details</h2>

	<table>
		<tr>
			<th colspan="2">
				<img style="border: 1px solid black;width: 80px;height: 70px;border-radius: 15%;" src="../../../uploads/profilePhotos/<?php echo e($getRestaurantDetails->logo); ?>">
			</th>
		</tr>
		<tr>
			<th>Restaurant Name </th>
			<th>
				<?php echo e($getRestaurantDetails->restaurantName); ?>

			</th>
		</tr>
		<tr>
			<th>Branch </th>
			<th>
				<?php echo e($getRestaurantDetails->branch); ?>

			</th>
		</tr>
		<tr>
			<th>Address </th>
			<th>
				<?php echo e($getRestaurantDetails->address); ?>

			</th>
		</tr>					
		<tr>
			<th>Email </th>
			<th>
				<?php echo e($getRestaurantDetails->email); ?>

			</th>
		</tr>
		<tr>
			<th>Phone  </th>
			<th>
				<?php echo e($getRestaurantDetails->phone); ?>

			</th>
		</tr>	
		<tr>
			<th>Owner Name  </th>
			<th>
				<?php echo e($getRestaurantDetails->ownerName); ?>

			</th>
		</tr>
		<tr>
			<th>Open Time - Close Time  </th>
			<th>
				<?php echo e($getRestaurantDetails->openTime); ?> - <?php echo e($getRestaurantDetails->closeTime); ?>

			</th>
		</tr>
		<tr>
			<th>Ratting  </th>
			<th>
				<?php echo e($getRestaurantDetails->ratting); ?>/5
			</th>
		</tr>
	</table>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('validation'); ?>

		<div style="width: 600px;height: 40px; margin: 0 auto; text-align: center;">
			<strong>All reviews</strong>
		</div>

		<div style="width: 600px;height: 307px; margin: 0 auto; overflow-y: scroll;">
		<?php $__currentLoopData = $restaurantReview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
		<table>
		<tr>
			<td>
			<img style="width: 50px;height: 50px;border-radius: 50%;" src="../../../uploads/profilePhotos/<?php echo e($review->photo); ?>">
			</td>
			<td> Review By <br> <?php echo e($review->name); ?></td>
			<td> Rating <br> <?php echo e($review->rate); ?></td>
			<td> Comment <br> <?php echo e($review->comment); ?></td>
			<td> Date <br> <?php echo e($review->date); ?></td>
		</tr>
		</table>
 
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>