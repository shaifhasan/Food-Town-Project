<?php $__env->startSection('pagetitle'); ?> Add Item to Order | Customer <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('customerHome')); ?>">Home</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('customerItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('order'); ?> <a href="<?php echo e(route('customerCart&Order')); ?>">Cart & Order</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('customerChangePass.edit', ['id' => $customerDetails->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style type="text/css">
	
table, tr, td, a {
    color: #46433e;
    padding-left: 20px;
    text-align: center;
    margin: 0 auto;
    height: 50px;
}

#welcomebox {
    width: 440px;
    height: 530px;
    background: #58584a75;
    position: absolute;
    color: #000;
    padding-left: 0%;
    margin-top: 2%;
    margin-left: 35%;
}

#validation {
	width: 320px;
    height: 78px;
    color: #e42828;
    padding-top: 3px;
    margin-top: 15%;
    left: 450px;
}


</style>

<h2>Add item to cart</h2>

<form method="post">
		<?php echo e(csrf_field()); ?>


<input type="hidden" name="itemID" value="<?php echo e($itemDetails->itemID); ?>">
<input type="hidden" name="regPrice" value="<?php echo e($itemDetails->regPrice); ?>">    
<input type="hidden" name="userID" value="<?php echo e($customerDetails->userID); ?>">
	<table>
		<tr>
			<th colspan="2">
				<img style="border: 1px solid black;width: 80px;height: 70px;border-radius: 15%;" src="../../../uploads/itemPhotos/<?php echo e($itemDetails->photo); ?>">
			</th>
		</tr>
		<tr>
			<th>Item Name </th>
			<th><input type="text" name="name" value="<?php echo e($itemDetails->name); ?>" disabled> </th>
		</tr>
		<tr>
			<th>Description </th>
			<th>
				<textarea rows="2" cols="20" name="description" disabled><?php echo e($itemDetails->description); ?></textarea>
			</th>
		</tr>
		<tr>
			<th>Price </th>
			<th><input type="text" name="price" value="<?php echo e($itemDetails->regPrice); ?>" disabled></th>
		</tr>					
		<tr>
			<th>Type </th>
			<th><input type="text" name="type" value="<?php echo e($itemDetails->foodType); ?>" disabled></th>
		</tr>
		<tr>
			<th>Select Quantity  </th>
			<th><input type="number" min="1" max="100" value="1" name="quantity" value="<?php echo e(old('quantity')); ?>"></th>
		</tr>	
		<tr>
			<th colspan="2"><h4>Are you sure about add this item to cart?</h4></th>
		</tr>
		<tr>
			<th><a href="<?php echo e(route('customerItem')); ?>">Back to all item List</a></th>
			<th><input type="submit" value="Add to cart"></th>
		</tr>
	</table>

</form>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('validation'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>