<?php $__env->startSection('pagetitle'); ?> Customer Registration <?php $__env->stopSection(); ?>	

<?php $__env->startSection('style'); ?>
<style type="text/css">

#Container{
    height: 580px;
    background: url(/images/bgreg.jpg);
    background-repeat: no-repeat;
    border-bottom: 6px solid #373940;
    background-position: bottom;
    background-size: cover;
}

#legend {
width: 355px;
    height: 100px;
    color: floralwhite;
    text-align: center;
    margin-top: 3%;
    margin-left: 38%;
}
	
#loginbox {
    height: 260px;
    width: 410px;
    top: 20%;
}

#validation {
	width: 290px;
    height: 195px;
    font-size: 18px;
    font-style: italic;
    margin-top: 119px;
    position: absolute;
    margin-left: 40%;
}

#footer{
    margin-top: 326px;
}
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('legend'); ?>
<h2>Not a member? Registration First!</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<form method="post">
		<?php echo e(csrf_field()); ?>

		
		<table>
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" value="<?php echo e(old('name')); ?>"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="email" value="<?php echo e(old('email')); ?>"></td>
			</tr>
			<tr> 
				<td>Gender</td> 
				<td><input type="radio" name="gender"  value="Male" 
					<?php if(old('gender')=="Male"): ?> checked <?php endif; ?>> Male
					<input type="radio" name="gender"  value="Female" 
					<?php if(old('gender')=="Female"): ?> checked <?php endif; ?>> Female
					<input type="radio" name="gender"  value="Other" 
					<?php if(old('gender')=="Other"): ?> checked <?php endif; ?>> Other
				</td>
			</tr>
			<tr>
				<td>Date of birth</td>
				<td>
					<input style="text-align: center;"  name="dob" type="date" value="<?php echo e(old('dob')); ?>"> </div>
				</td>
			</tr>
			<tr>
				<td>Address</td>
				<td><input type="text" name="address" value="<?php echo e(old('address')); ?>"></td>
			</tr>
			<tr>
				<td>Phone</td>
				<td><input type="text" name="phone" value="<?php echo e(old('phone')); ?>"></td> 
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="Password" name="password" value="<?php echo e(old('password')); ?>"></td> 
			</tr>
			<tr>
				<td>Retype Password</td>
				<td><input type="Password" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>"></td> 
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Registration"></td>
			</tr>
		</table>
 
	</form>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('validation'); ?>

	<?php if($errors->any()): ?>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	<?php endif; ?>

	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>