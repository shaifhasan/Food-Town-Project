<?php $__env->startSection('pagetitle'); ?> Order List | Customer <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('customerHome')); ?>">Home</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('customerItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('order'); ?> <a href="<?php echo e(route('customerCart&Order')); ?>">Cart & Order</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('customerChangePass.edit', ['id' => $customerDetails->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style type="text/css">
#validation {
    width: 90%;
    margin-top: 8%;
    height: 50%;
    margin-left: 5%;
    overflow-y: scroll;
}

table, tr, td, a {
    color: #46433e;
    padding-left: 10px;
    padding-right: 10px;
    text-align: center;
    margin: 0 auto;
    height: 25px;
}

#sticky {
    position: sticky;
    top: 0;
    background-color: #d1d1d1;
    font-size: 20px;
}

#welcomebox {
    width: 420px;
    position: absolute;
    height: 70px;
    background: #58584a75;
    color: #000;
    font-size: 15px;
    box-sizing: border-box;
    border-radius: 20px;
    padding: 5px;
    /* margin: 8px auto; */
    text-align: center;
    /* padding-bottom: 14px; */
    margin-top: 10px;
    left: 35%;
}

#fixedBottomLabel{
  width: 88%;
    height: 7%;
    position: fixed;
    margin-top: 32%;
    margin-left: 5%;
    padding-top: 20px;
    text-align: center;
    background: #58584a75;
    border-radius: 20%;
}

</style>

	<h2>Your Order History</h2>
	<br>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('validation'); ?>
	<table>
		<tr>
			<th id="sticky">OrderID </th>
			<th id="sticky">Items</th>
			<th id="sticky">Total Amount</th>
			<th id="sticky">Payment </th>
			<th id="sticky">Address </th>
			<th id="sticky">Phone </th>
			<th id="sticky">Date </th>
			<th id="sticky">Time</th>
		</tr>
		<tr>
			<td colspan="8">------------------------------------------------------------------------------------------------------------------------------------------------------</td>
		</tr>
		<?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<th><?php echo e($order->orderID); ?></th>
			<th>
				<?php $__currentLoopData = $itemDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($order->orderID==$item->orderID): ?>
				<ul>
  					<li><?php echo e($item->name); ?></li>
				</ul>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</th>
			<th><?php echo e($order->totalAmount); ?></th>
			<th><?php echo e($order->paymentType); ?></th>
			<th><?php echo e($order->address); ?></th>
			<th><?php echo e($order->phone); ?></th>
			<th><?php echo e($order->date); ?></th>
			<th><?php echo e($order->time); ?></th>
			<th></th>
		</tr>
		<tr>
			<td colspan="8">------------------------------------------------------------------------------------------------------------------------------------------------------</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>