<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Login</h2>
	<form method="post">
		<?php echo e(csrf_field()); ?>

		<table>
			<tr>
				<td>USERNAME</td>
				<td><input type="text" name="username"/></td>
			</tr>
			<tr>
				<td>PASSWORD</td>
				<td><input type="password" name="password"/></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Login" /></td>
			</tr>
		</table>
	</form>

	<?php if(session('message')): ?>
		<?php echo e(session('message')); ?>

	<?php endif; ?>

	<?php if($errors->any()): ?>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	<?php endif; ?>
</body>
</html>