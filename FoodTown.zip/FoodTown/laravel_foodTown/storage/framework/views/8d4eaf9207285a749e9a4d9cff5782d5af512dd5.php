<?php $__env->startSection('pagetitle'); ?> Item Cart | Customer <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('customerHome')); ?>">Home</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('customerItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('order'); ?> <a href="<?php echo e(route('customerCart&Order')); ?>">Cart & Order</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('customerChangePass.edit', ['id' => $customerDetails->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style type="text/css">
#validation {
    width: 90%;
    margin-top: 8%;
    height: 50%;
    margin-left: 5%;
    overflow-y: scroll;
}

table, tr, td, a {
    color: #46433e;
    padding-left: 10px;
    padding-right: 10px;
    text-align: center;
    margin: 0 auto;
    height: 25px;
}

#welcomebox {
    width: 420px;
    position: absolute;
    height: 70px;
    background: #58584a75;
    color: #000;
    font-size: 15px;
    box-sizing: border-box;
    border-radius: 20px;
    padding: 5px;
    /* margin: 8px auto; */
    text-align: center;
    /* padding-bottom: 14px; */
    margin-top: 10px;
    left: 35%;
}

#fixedBottomLabel{
  width: 88%;
    height: 7%;
    position: fixed;
    margin-top: 32%;
    margin-left: 5%;
    padding-top: 20px;
    text-align: center;
    background: #58584a75;
    border-radius: 20%;
}

</style>

	<h2>Items in cart list</h2>
	<br>
	<a href="<?php echo e(route('customerItem.orderList')); ?>">View Order List</a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('validation'); ?>
	<table>
		<tr>
			<th>Photo </th>
			<th>Item</th>
			<th>Quantity</th>
			<th>Total Price </th>
			<th>Available </th>
			<th>Added Date </th>
			<th>Status </th>
			<th>Option</th>
		</tr>
		<tr>
			<td colspan="8">------------------------------------------------------------------------------------------------------------------------------------------------------</td>
		</tr>

		<?php $__currentLoopData = $cartList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<?php if($item->status!="Delivered" && $item->status!="Postponed"  && $item->status!="Ordered"  && $item->availability=="Yes"): ?>
		<tr>
			<td>
				<img style="border: 1px solid black;width: 100px;height: 90px;border-radius: 15%;" src="../../../uploads/itemPhotos/<?php echo e($item->photo); ?>">
			</td> 
			<td><?php echo e($item->name); ?> <br> <?php echo e($item->foodType); ?></td>
			<td><?php echo e($item->quantity); ?></td>
			<td><?php echo e($item->grossPrice); ?>  .tk</td>
			<td><?php echo e($item->availability); ?></td>
			<td><?php echo e($item->addedAtDate); ?></td>
			<td><?php echo e($item->status); ?></td>
			<td>
				 <a href="<?php echo e(route('customerCart.edit', ['cartID' => $item->cartID])); ?>">Edit Cart</a> |
				 <a href="<?php echo e(route('customerCart.remove', ['cartID' => $item->cartID])); ?>">Remove</a>
			</td>
		</tr>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('fixedBottomLabel'); ?>
	<div id="fixedBottomLabel">
		<table style="margin-top: 0px">
			<tr>
				<th>Total Amount: <?php echo e($totalAmount); ?> .tk</th>
				<?php if($item->status!="Ordered" && $item->availability=="Yes"): ?>
				<th><a style="color: #762929;" href="<?php echo e(route('customerItem.order')); ?>">Order Now</a></th>
				<?php endif; ?>
			</tr>
		</table>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>