<?php $__env->startSection('pagetitle'); ?> Restaurent Review | Customer <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('customerHome')); ?>">Home</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('customerItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('order'); ?> <a href="<?php echo e(route('customerCart&Order')); ?>">Cart & Order</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('customerChangePass.edit', ['id' => $customerDetails->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style type="text/css">
	
table, tr, td, a {
    color: #46433e;
    padding-left: 20px;
    text-align: center;
    margin: 0 auto;
    height: 38px;
}

#welcomebox {
    width: 490px;
    height: 530px;
    background: #58584a75;
    position: absolute;
    color: #000;
    padding-left: 0%;
    margin-top: 2%;
    margin-left: 8%;
}

#validation {
	width: 650px;
    height: 490px;
    color: #e42828;
    padding-top: 3px;
    margin-top: 3%;
    left: 110px;
}


</style>

<h2>Restaurent Details</h2>

	<table>
		<tr>
			<th colspan="2">
				<img style="border: 1px solid black;width: 80px;height: 70px;border-radius: 15%;" src="../../../uploads/profilePhotos/<?php echo e($restaurantDetails->logo); ?>">
			</th>
		</tr>
		<tr>
			<th>Restaurant Name </th>
			<th>
				<?php echo e($restaurantDetails->restaurantName); ?>

			</th>
		</tr>
		<tr>
			<th>Branch </th>
			<th>
				<?php echo e($restaurantDetails->branch); ?>

			</th>
		</tr>
		<tr>
			<th>Address </th>
			<th>
				<?php echo e($restaurantDetails->address); ?>

			</th>
		</tr>					
		<tr>
			<th>Email </th>
			<th>
				<?php echo e($restaurantDetails->email); ?>

			</th>
		</tr>
		<tr>
			<th>Phone  </th>
			<th>
				<?php echo e($restaurantDetails->phone); ?>

			</th>
		</tr>	
		<tr>
			<th>Owner Name  </th>
			<th>
				<?php echo e($restaurantDetails->ownerName); ?>

			</th>
		</tr>
		<tr>
			<th>Open Time - Close Time  </th>
			<th>
				<?php echo e($restaurantDetails->openTime); ?> - <?php echo e($restaurantDetails->closeTime); ?>

			</th>
		</tr>
		<tr>
			<th>Ratting  </th>
			<th>
				<?php echo e($restaurantDetails->ratting); ?>/5
			</th>
		</tr>
		<tr>
			<th colspan="2"><a href="<?php echo e(route('customerItem')); ?>">Back to all items list</a></th>
		</tr>
	</table>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('validation'); ?>

<form method="post">
		<?php echo e(csrf_field()); ?>


		<input type="hidden" name="userID" value="<?php echo e($customerDetails->userID); ?>">
		<input type="hidden" name="restaurantID" value="<?php echo e($restaurantDetails->userID); ?>">
		<div style="height: 100px; width: 400px; margin: 0 auto; margin-top: 20px;">
			<table>
			<tr>
				<th>Your Ratting: </th>
				<th>
					<input type="number" name="rate" min="0" max="5" placeholder="0-5" value="<?php echo e($myReview->rate); ?>">
				</th>
				<th></th>
			</tr>
			<tr>
				<th>Your Comment: </th>
				<th>
					<textarea rows="2" cols="20" name="comment" placeholder="write your comment..." required><?php echo e($myReview->comment); ?></textarea> 
				</th>
				<th><input type="submit" value="Post"></th>
			</tr>
			
		</table>
		</div>

		<br>
		<div style="width: 600px;height: 40px; margin: 0 auto; text-align: center;">
			<strong>All reviews</strong>
		</div>

		<div style="width: 600px;height: 307px; margin: 0 auto; overflow-y: scroll;">
		<?php $__currentLoopData = $restaurantReview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
		<table>
		<tr>
			<td>
			<img style="width: 50px;height: 50px;border-radius: 50%;" src="../../../uploads/profilePhotos/<?php echo e($review->photo); ?>">
			</td>
			<td> Review By <br> <?php echo e($review->name); ?></td>
			<td> Rating <br> <?php echo e($review->rate); ?></td>
			<td> Comment <br> <?php echo e($review->comment); ?></td>
			<td> Date <br> <?php echo e($review->date); ?></td>
		</tr>
		</table>
 
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

</form>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>