<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $__env->yieldContent('pagetitle'); ?></title>
<link rel="stylesheet" type="text/css" href="autumn05.css" />
</head>
<body>
<div id="container">
  <div id="navarea">
    <ul id="nav">
      <li><a href="#" title="home">home</a></li>
      <li><a href="#" title="about">about</a></li>
      <li><a href="#" title="archive">archive</a></li>
      <li><a href="#" title="contact">contact</a></li>
      <li><a href="#" title="links">links</a></li>
    </ul>
  </div>
  <div id="hdr"> <span id="sitetitle">Lorem ipsu</span> <br />
    <span id="subtitle">Lorem ipsum dolor sit</span></div>
  <div id="lftcol">
    <div class="leftcolbox">
      <div class="leftcolboxtop"></div>
      <h2>Left Column</h2>
      <p>This is a left column item.  You could put anything in here you like including images, text or links.</p>
    </div>
    <div class="leftcolbox">
      <div class="leftcolboxtop"></div>
      <h2>Useful links:</h2>
      <p> <a href="#">» Home</a><br />
        <a href="#">» Contact</a><br />
        <a href="#">» About</a><br />
        <a href="#">» Product</a><br />
        <a href="#">» FAQ</a></p>
      <br />
    </div>
  </div>
  

  <?php echo $__env->yieldContent('content'); ?>


  <div id="bttmbar"> <span id="copyright"> Copyright &copy; 2005. Your copyright info here.</span>
    <ul id="bttmnav">
      <li><a href="" title="home">home</a></li>
      <li><a href="" title="about">about</a></li>
      <li><a href="" title="archive">archive</a></li>
      <li><a href="" title="contact">contact</a></li>
      <li><a href="" title="links">links</a></li>
    </ul>
  </div>
</div>
</body>
</html>
