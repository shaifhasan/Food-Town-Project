<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Create New Employee</h2>
	<a href="<?php echo e(route('employee.list')); ?>">Back to List</a>
	<br/><br/>
	<form method="post">
		<table>
			<tr>
				<td>NAME</td>
				<td><input type="text" name="ename" value="<?php echo e(old('ename')); ?>"></td>
			</tr>
			<tr>
				<td>EMAIL</td>
				<td><input type="text" name="email" value="<?php echo e(old('email')); ?>"></td>
			</tr>
			<tr>
				<td>SALARY</td>
				<td><input type="text" name="sal" value="<?php echo e(old('sal')); ?>"></td>
			</tr>
			<tr>
				<td>DEPARTMENT</td>
				<td>
					<select name="dept">
						<?php $__currentLoopData = $deptlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($dept->department_id); ?>"><?php echo e($dept->department_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Save"></td>
			</tr>
		</table>
	</form>

	<?php if($errors->any()): ?>
	
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

	<?php endif; ?>
</body>
</html>