<?php $__env->startSection('pagetitle'); ?> Food Town | Login <?php $__env->stopSection(); ?>	


<?php $__env->startSection('legend'); ?>
<h2>Login Here</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<form method="post">
		<?php echo e(csrf_field()); ?>

		<table>
			<tr>
				<td>Email</td>
				<td><input type="text" value="<?php echo e(old('email')); ?>" name="email"/></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" value="<?php echo e(old('password')); ?>" name="password"/></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Login" /></td>
			</tr>
			<tr>
				<td></td>
				<td> Forget password? <a id="tablehref" href="<?php echo e(route('resetpassword')); ?>">Reset!</a></td>
			</tr>
		</table>
	</form>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('validation'); ?>
		<?php if(session('message')): ?>
		<ul>
				<li><?php echo e(session('message')); ?></li>
		</ul>
	<?php endif; ?>

	<?php if($errors->any()): ?>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	<?php endif; ?>

	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>