<?php $__env->startSection('pagetitle'); ?> Items | Restaurant <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('restaurantProfile')); ?>">Profile</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('restaurantItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('order'); ?> <a href="<?php echo e(route('restaurantOrder')); ?>">Order</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('restaurantChangePass.edit', ['id' => $restaurantDetails->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<style type="text/css">
	
#validation {
    width: 89%;
    margin-top: 10%;
    height: 60%;
    margin-left: 5%;
    overflow-y: scroll;
}

#sticky {
   
    position: sticky;
    top: 0;
    background-color: #d1d1d1;
    font-size: 20px;
}

table, tr, td, a {
    color: #46433e;
    padding-left: 10px;
    padding-right: 10px;
    text-align: center;
    margin: 0 auto;
    margin-top: 25px;
    height: 30px;
}

#welcomebox {
    width: 420px;
    position: absolute;
    height: 70px;
    background: #58584a75;
    color: #000;
    font-size: 15px;
    box-sizing: border-box;
    border-radius: 20px;
    padding: 5px;
    /* margin: 8px auto; */
    text-align: center;
    /* padding-bottom: 14px; */
    margin-top: 20px;
    left: 35%;
}


</style>

	<h2>All Items List</h2>
	<br>
	<a style="color: black; font-size: 18px;" href="<?php echo e(route('restaurantCreateItem')); ?>">Create New Item</a>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('validation'); ?>
	<table>
		<tr>
			<th id="sticky">Photo </th>
			<th id="sticky">Item Name </th>
			<th id="sticky">Description </th>
			<th id="sticky">Type </th>
			<th id="sticky">Price </th>
			<th id="sticky">Available </th>
			<th id="sticky">Option</th>
		</tr>
		<?php $__currentLoopData = $itemList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td>
				<img style="border: 1px solid black;width: 100px;height: 90px;border-radius: 15%;" src="../../../uploads/itemPhotos/<?php echo e($item->photo); ?>">
			</td> 
			<td><?php echo e($item->name); ?></td>
			<td><?php echo e($item->description); ?></td>
			<td><?php echo e($item->foodType); ?></td>
			<td><?php echo e($item->regPrice); ?> .tk</td>
			<td><?php echo e($item->availability); ?></td>
			<td>
				<a href="<?php echo e(route('restaurantItem.edit', ['itemID' => $item->itemID])); ?>">Edit</a>  |
				<a href="<?php echo e(route('restaurantItem.delete', ['itemID' => $item->itemID])); ?>">Delete</a> 
			</td>
		</tr>
		<tr>
			<td colspan="7">----------------------------------------------------------------------------------------------------------------</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>