<!DOCTYPE html>
<html>
<head>
	<title> <?php echo $__env->yieldContent('pagetitle'); ?> </title>
	<link rel="stylesheet" type="text/css" href="/css/global.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.parallax {
    /* The image used */
   background: url(/images/bglogin.jpg);
    /* Set a specific height */
    min-height: 500px; 

    /* Create the parallax scrolling effect */
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}

#scroll{
	margin-left: 450px;
	margin-top: 200px;
	float: left;
}
</style>

	<?php echo $__env->yieldContent('style'); ?>

<div class="loginHeader"> 


	<span><a style="text-decoration: none; color: #d8d33c;" href="<?php echo e(route('login')); ?>" class="hvr-underline-from-center"> Food Town </a></span>
		<nav> 
			<ul>
				<li>
					<a href="<?php echo e(route('login')); ?>" class="hvr-underline-from-center"> Login </a>
				</li>
				<li>
					<a href="<?php echo e(route('customerRegistration')); ?>" class="hvr-underline-from-center"> Order Food </a>
				</li>
				<li>
					<a href="<?php echo e(route('restaurantRegistration')); ?>" class="hvr-underline-from-center"> Open Restaurant </a>
				</li>
				<li>
					<a href="<?php echo e(route('contact')); ?>" class="hvr-underline-from-center"> Contact</a>
				</li>
				<li>
					<a href="<?php echo e(route('faq')); ?>" class="hvr-underline-from-center"> About & FAQ</a>
				</li>
			</ul>
		</nav>
	</div>

</head>
<body>
<div class="parallax">
	<div id="Container">
<div id="scroll"><h1 style="color: white">Scroll down</h1></div>
</div>
<div id="Container">

		<div id="legend">
			<?php echo $__env->yieldContent('legend'); ?>
		</div>

		<div id="loginbox">
			<?php echo $__env->yieldContent('content'); ?>  
		</div>


		<div id="validation">
			<?php echo $__env->yieldContent('validation'); ?>  
		</div>
</div>
		<div id="footer">
		<p>&copy; 2018 Food Town. All rights reserved. Developed by <a href="#">White Walkers Team</a></p>
		</div>

	</div>

</body>
</html>