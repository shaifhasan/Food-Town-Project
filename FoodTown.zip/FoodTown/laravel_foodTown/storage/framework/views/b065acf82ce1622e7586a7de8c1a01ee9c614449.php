<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="<?php echo e(route('create')); ?>">Create</a>
	<br/>
	<br/>
	<p>Your name is <?php echo e($name); ?></p>
	<p>Your email is <?php echo e($email); ?></p>
	<p>Your email is <?php echo e($age); ?></p>
</body>
</html>