<?php $__env->startSection('pagetitle'); ?> Profile | Admin <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('adminHome')); ?>">Home</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('adminItem')); ?>">Item</a> <?php $__env->stopSection(); ?>  

<?php $__env->startSection('order'); ?> <a href="<?php echo e(route('adminReport')); ?>">Report</a> <?php $__env->stopSection(); ?>  

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('adminChangePassword.edit', ['id' => session('user')->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
	table, tr, td, a{
color: black;
    padding-top: 10px;
    font-size: 16px;
     border-collapse: collapse;
}
#welcomebox {
    width: 420px;
    height: 370px;
    background: #58584a75;
    position: absolute;
    color: #000;
    padding-left: 5.6%;
    padding-top: 1.5%;
    margin-top: 6%;
    margin-left: 35%;
}

#validation {
    width: 0px;
    height: 0px;
}

</style>


	<table>
							

							<td colspan="2">
					<?php if($adminDetails->photo=="none"): ?>
						<img style="border-radius: 50%; border: 1px solid black; width: 80px; height: 80px;" src="../../../uploads/profilePhotos/default.jpg">
					<?php else: ?>
						<img style="border-radius: 50%; border: 1px solid black; width: 80px; height: 80px;" src="../../../uploads/profilePhotos/<?php echo e($adminDetails->photo); ?>">
					<?php endif; ?>
							</td>	

							<tr>
								<th>Name : </th>
								<td><?php echo e($adminDetails->name); ?></td>
							</tr>

							<tr>
								<th>Email : </th>
								<td><?php echo e($adminDetails->email); ?></td>
							</tr>

							<tr>
								<th>Gender : </th>
								<td><?php echo e($adminDetails->gender); ?></td>
							</tr>

							<tr>
								<th>Date of birth : </th>
								<td><?php echo e($adminDetails->dob); ?></td>
							</tr>

							<tr>
								<th>Address : </th>
								<td><?php echo e($adminDetails->address); ?></td>
							</tr>

							<tr>
								<th>Phone : </th>
								<td><?php echo e($adminDetails->phone); ?></td>
							</tr>

							<tr>
								<th>Join Date : </th>
								<td><?php echo e($adminDetails->joinDate); ?></td>
							</tr>
							<tr>
								<th></th>
									<td>
										<a  href="<?php echo e(route('adminProfile.edit', ['id' => $adminDetails->userID])); ?>">Edit Profile</a>
									</td>
							</tr>
							
					</table>
					
					
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>