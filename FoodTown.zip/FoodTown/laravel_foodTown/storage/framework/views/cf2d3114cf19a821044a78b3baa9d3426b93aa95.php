<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Welcome <?php echo e(session('user')->name); ?></h2>
	<a href="<?php echo e(route('department.list')); ?>">Departments</a> | 
	<a href="<?php echo e(route('employee.list')); ?>">Employees</a> | 
	<a href="<?php echo e(route('logout')); ?>">Logout</a>
</body>
</html>