<!DOCTYPE html>
<html>
<head>
	<title>Error</title>
</head>
<body>
<h1>Unauthorised Access!! Something Went Wrong! Please <a href="<?php echo e(route('logout')); ?>">Try Login Again!</a>. </h1>
</body>
</html>