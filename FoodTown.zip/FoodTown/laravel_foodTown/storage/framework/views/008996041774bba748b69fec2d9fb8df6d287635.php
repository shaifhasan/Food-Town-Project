<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Create View</h2>
	<form method="post">
		NAME: <input type="text" name="myname" value="<?php echo e(old('myname')); ?>">
		<?php if($errors->any()): ?>
			<?php echo e($errors->first('myname')); ?>

		<?php endif; ?>
		<br/>
		EMAIL: <input type="text" name="myemail" value="<?php echo e(old('myemail')); ?>"><br/>
		AGE: <input type="text" name="myage" value="<?php echo e(old('myage')); ?>"><br/>
		<input type="submit" value="Submit"><br/>
	</form>

	<?php if($errors->any()): ?>
	
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

	<?php endif; ?>
</body>
</html>