<?php $__env->startSection('pagetitle'); ?> Customer | Home <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('customerHome')); ?>">Home</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('customerItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('order'); ?> <a href="<?php echo e(route('customerCart&Order')); ?>">Cart & Order</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('customerChangePass.edit', ['id' => $customerDetails->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<style type="text/css">

	table, tr, td, a{
color: black;
    padding-top: 10px;
    font-size: 16px;
     border-collapse: collapse;
}

#welcomebox {
    width: 440px;
    height: 425px;
    background: #58584a75;
    position: absolute;
    color: #000;
    padding-left: 3.5%;
    margin-top: 2%;
    margin-left: 35%;
}

#validation {
	width: 320px;
    height: 78px;
    color: #e42828;
    padding-top: 3px;
    margin-top: 32%;
    left: -15px;
}

</style>

<h2 style="position: relative; left: -20px;">Edit Profile</h2>
	<form method="post" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="userId" value="<?php echo e($customerDetails->userID); ?>">  
		<input type="hidden" name="photo" value="<?php echo e($customerDetails->photo); ?>">  
		<table>
			<tr>
				<td>
					<?php if($customerDetails->photo=="none"): ?>
						<img style="border-radius: 50%; border: 1px solid black; width: 80px; height: 80px;" src="../../../uploads/profilePhotos/default.jpg">
					<?php else: ?>
						<img style="border-radius: 50%; border: 1px solid black; width: 80px; height: 80px;" src="../../../uploads/profilePhotos/<?php echo e($customerDetails->photo); ?>">
					<?php endif; ?>
				</td>
				<td>
					<input type="file" name="file" accept="image/*">
				</td>
			</tr>
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" value="<?php echo e($customerDetails->name); ?>"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="email" value="<?php echo e($customerDetails->email); ?>"></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td><input type="radio" name="gender"  value="Male" 
					<?php if($customerDetails->gender=="Male"): ?> checked <?php endif; ?>> Male
					<input type="radio" name="gender"  value="Female" 
					<?php if($customerDetails->gender=="Female"): ?> checked <?php endif; ?>> Female
					<input type="radio" name="gender"  value="Other" 
					<?php if($customerDetails->gender=="Other"): ?> checked <?php endif; ?>> Other
				</td>
			</tr>
			<tr>
				<td>Date of birth</td>
				<td>
					<input style="text-align: center;" name="dob" type="date" value="<?php echo e($customerDetails->dob); ?>"> </div>
				</td>
			</tr>
			<tr>
				<td>Address</td>
				<td><input type="text" name="address" value="<?php echo e($customerDetails->address); ?>"></td>
			</tr>
			<tr>
				<td>Phone</td>
				<td><input type="text" name="phone" value="<?php echo e($customerDetails->phone); ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Save"></td>
			</tr>
		</table>
	</form>					
<?php $__env->stopSection(); ?>

<?php $__env->startSection('validation'); ?>
	<?php if($errors->any()): ?>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

 
 
<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>