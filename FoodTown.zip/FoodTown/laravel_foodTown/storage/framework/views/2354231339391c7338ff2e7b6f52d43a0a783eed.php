<?php $__env->startSection('pagetitle'); ?> Report | Admin <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('adminProfile')); ?>">Profile</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('adminItem')); ?>">Item</a> <?php $__env->stopSection(); ?>  

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('adminChangePassword.edit', ['id' => session('user')->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
table, tr, td, a{
color: black;
    padding-top: 10px;
    font-size: 16px;
     border-collapse: collapse;
}
#tabletop
{
   margin-top: 30px;
}
#td
{
	margin-right:10px;
}
#divbox
{
	background-color: #e8e4e2;
	height: 300px;
	position: static;
	width: 500px;
	margin-left: -50px;
	margin-top: 100px;
	overflow-y: auto;
	box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
}
	
	
}


input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    background-color : #d1d1d1; 
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #d1d1d1;
    color: black;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color:#f7f5ec;
}

	
</style>
	<h2>Report</h2>

	<div id="divbox" >
		<p>Total Number of Customer............................................<?php echo e($customerCount); ?></p>
		<p>Total Number of Restaurant..........................................<?php echo e($restaurantCount); ?></p>
		<p>Total Amount of Transaction..................................<?php echo e($totalTransaction); ?></p>
		<p>Most Rated Restaurants...................................<?php echo e($mostRated->restaurantName); ?></p>
		
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>