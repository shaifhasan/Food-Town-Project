<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Create New Department</h2>
	<a href="<?php echo e(route('department.list')); ?>">Back to List</a>
	<br/><br/>
	<form method="post">
		<table>
			<tr>
				<td>NAME</td>
				<td><input type="text" name="dname"></td>
			</tr>
			<tr>
				<td>LOCATION</td>
				<td><input type="text" name="loc"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Save"></td>
			</tr>
		</table>
	</form>
</body>
</html>