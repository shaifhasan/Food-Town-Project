<?php $__env->startSection('pagetitle'); ?> Change Password | Customer <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('customerHome')); ?>">Home</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('customerItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('order'); ?> <a href="<?php echo e(route('customerCart&Order')); ?>">Cart & Order</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('customerChangePass.edit', ['id' => $currentInfo->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style type="text/css">
	table, tr, td, a{
color: black;
    padding-top: 10px;
    font-size: 16px;
     border-collapse: collapse;
}
#welcomebox {
    width: 420px;
    height: 250px;
    background: #58584a75;
    position: absolute;
    color: #000;
    padding-left: 3.5%;
    padding-top: 1.5%;
    margin-top: 3%;
    margin-left: 35%;
}

#validation {
width: 416px;
    height: 220px;
    font-size: 18px;
    font-style: italic;
    margin-top: 319px;
    position: absolute;
    margin-left: 35%;
    color: black;
    text-align: center;
}

</style>


	<form method="post">
		<?php echo e(csrf_field()); ?>


	<input type="hidden" name="thisPassword" value="<?php echo e($currentInfo->password); ?>">

	<input type="hidden" name="userID" value="<?php echo e($currentInfo->userID); ?>">

	<table>
							
		<tr>
				<td colspan="2">
				<h2>Change Password</h2>
				</td>
		</tr>
		<tr>
				<th>Current Password : </th>
				<td>
					<input type="password" value="<?php echo e(old('currentPassword')); ?>" name="currentPassword" >
				</td>
			</tr>
			<tr>
				<th>New Password : </th>
				<td>
					<input type="password" value="<?php echo e(old('password')); ?>" name="password">
				</td>
			</tr>
			<tr>
				<th>Retype New Password : </th>
				<td>
					<input type="password" value="<?php echo e(old('password_confirmation')); ?>" name="password_confirmation" >
				</td>
			</tr>
			<tr>
				<th></th>
				<td><input type="submit" value="Change"></td>
			</tr>
							
							
	</table>
</form>
					
<?php $__env->stopSection(); ?>


<?php $__env->startSection('validation'); ?>

	<?php if($errors->any()): ?>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	<?php endif; ?>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>