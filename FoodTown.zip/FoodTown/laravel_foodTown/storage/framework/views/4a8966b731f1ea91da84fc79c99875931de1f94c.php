<?php $__env->startSection('content'); ?>
<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<h2>Department List</h2>
				<a class="btn btn-primary" href="<?php echo e(route('department.create')); ?>">Create New</a>
				<br/><br/>
				<div class="panel panel-info">
					<div class="panel-heading">List of Departments</div>
					<div class="panel-body">
						<table class="table table-striped">
							<tr>
								<th>ID</th>
								<th>NAME</th>
								<th>LOCATION</th>
								<th>OPTIONS</th>
							</tr>
							<?php $__currentLoopData = $deptlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($dept->department_id); ?></td>
								<td><?php echo e($dept->department_name); ?></td>
								<td><?php echo e($dept->location); ?></td>
								<td><a href="<?php echo e(route('department.edit', ['id' => $dept->department_id])); ?>">Edit</a> | <a href="<?php echo e(route('department.delete', ['id' => $dept->department_id])); ?>">Delete</a></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('styles'); ?>
		<link rel="stylesheet" type="text/css" href="aksdgajshdg">
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('pagetitle'); ?>
		Department List
	<?php $__env->stopSection(); ?>	
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>