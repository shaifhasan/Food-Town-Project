<?php $__env->startSection('pagetitle'); ?> Customer Registration <?php $__env->stopSection(); ?>	

<?php $__env->startSection('style'); ?>
<style type="text/css">

#Container{
    height: 580px;
    background: url(/images/bgres.jpg);
    background-repeat: no-repeat;
    border-bottom: 6px solid #373940;
    background-position: bottom;
    background-size: cover;
}

#legend {
    width: 355px;
    height: 100px;
    color: floralwhite;
    text-align: center;
    position: absolute;
    margin-top: 2%;
    margin-left: 38%;
}
	
#loginbox {
    height: 260px;
    width: 380px;
    top: 15%;
}

#validation {
    width: 290px;
    height: 210px;
    font-size: 18px;
    font-style: italic;
    margin-top: 100px;
    position: absolute;
    margin-left: 40%;
}

#footer{
    margin-top: 326px;
}
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('legend'); ?>
<h2>Open your restaurant online!</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<form method="post">
		<?php echo e(csrf_field()); ?>

		
		<table>
			<tr>
				<td>Restaurant Name</td>
				<td><input type="text" name="restaurantName" value="<?php echo e(old('restaurantName')); ?>"></td>
			</tr>
			<tr> 
				<td>Branch</td> 
				<td><input type="text" name="branch" value="<?php echo e(old('branch')); ?>"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="email" value="<?php echo e(old('email')); ?>"></td>
			</tr>
			<tr>
				<td>Address</td>
				<td><input type="text" name="address" value="<?php echo e(old('address')); ?>"></td>
			</tr>
			<tr>
				<td>Phone</td>
				<td><input type="text" name="phone" value="<?php echo e(old('phone')); ?>"></td>
			</tr>
			<tr>
				<td>Owner Name</td>
				<td><input type="text" name="owner" value="<?php echo e(old('owner')); ?>"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="Password" name="password" value="<?php echo e(old('password')); ?>"></td> 
			</tr>
			<tr>
				<td>Retype Password</td>
				<td><input type="Password" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>"></td> 
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Registration"></td>
			</tr>
		</table>
 
	</form>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('validation'); ?>

	<?php if($errors->any()): ?>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	<?php endif; ?>

	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>