<?php $__env->startSection('pagetitle'); ?> New Item | Restaurant <?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?> <a href="<?php echo e(route('restaurantProfile')); ?>">Profile</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('item'); ?> <a href="<?php echo e(route('restaurantItem')); ?>">Item</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('changePass'); ?> <a href="<?php echo e(route('restaurantChangePass.edit', ['id' => $restaurantDetails->userID])); ?>}">Change Password</a> <?php $__env->stopSection(); ?>

<?php $__env->startSection('logout'); ?> <a href="<?php echo e(route('logout')); ?>">Logout</a> <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<style type="text/css">
	
table, tr, td, a {
    color: #46433e;
    padding-left: 20px;
    text-align: center;
    margin: 0 auto;
    height: 50px;
}

#welcomebox {
    width: 440px;
    height: 480px;
    background: #58584a75;
    position: absolute;
    color: #000;
    padding-left: 2%;
    margin-top: 4%;
    margin-left: 35%;
}

#validation {
	width: 320px;
    height: 78px;
    color: #e42828;
    padding-top: 3px;
    margin-top: 15%;
    left: 450px;
}


</style>

	<h2>Create new item</h2>
	<br>

<form method="post" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

<input type="hidden" name="userID" value="<?php echo e($restaurantDetails->userID); ?>"> 
	<table>
		<tr>
			<th>Select Photo</th>
			<th><input type="file" name="file" accept="image/*"></th>
		</tr>
		<tr>
			<th>Item Name </th>
			<th><input type="text" name="name" value="<?php echo e(old('name')); ?>"> </th>
		</tr>
		<tr>
			<th>Description </th>
			<th>
				<textarea rows="2" cols="20" name="description" value="<?php echo e(old('description')); ?>"> </textarea>
			</th>
		</tr>
		<tr>
			<th>Price </th>
			<th><input type="text" name="price" value="<?php echo e(old('price')); ?>" placeholder=".tk "></th>
		</tr>
		<tr>
			<th>Available </th>
			<th>
                <input type="radio" name="availability"  value="Yes"> Yes
                <input type="radio" name="availability"  value="No"> No
            </th>
		</tr>						
		<tr>
			<th>Type </th>
			<th> 
				<select name="type"> 
               	 	<option selected disabled>select</option>
                	<option value="Single Pack">Single Pack </option>
                	<option value="Combo Pack">Combo Pack</option>
                	<option value="Buy 1 Get 1">Buy 1 Get 1</option>
                </select> 
			</th>
		</tr>
		<tr>
			<th></th>
			<th><input type="submit" value="Create item"></th>
		</tr>
	</table>
</form>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('validation'); ?>
	<?php if($errors->any()): ?>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.defaultHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>